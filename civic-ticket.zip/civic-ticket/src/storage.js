// The app was built against the `window.storage` key-value API that Claude
// artifacts provide. Outside Claude that API doesn't exist, so this file
// emulates it with localStorage.
//
// NOTE: localStorage is per-browser. The "shared" flag is kept for API
// compatibility, but data is NOT shared between different users/devices.
// For a genuinely shared board, replace this file with a backend adapter
// (Firebase, Supabase, your own API) exposing the same get/set/delete/list.

if (typeof window !== "undefined" && !window.storage) {
  const scoped = (key, shared) => `civic-ticket/${shared ? "shared" : "personal"}/${key}`;

  window.storage = {
    async get(key, shared = false) {
      const value = localStorage.getItem(scoped(key, shared));
      if (value === null) throw new Error(`Key not found: ${key}`);
      return { key, value, shared };
    },
    async set(key, value, shared = false) {
      localStorage.setItem(scoped(key, shared), value);
      return { key, value, shared };
    },
    async delete(key, shared = false) {
      localStorage.removeItem(scoped(key, shared));
      return { key, deleted: true, shared };
    },
    async list(prefix = "", shared = false) {
      const base = scoped("", shared);
      const keys = Object.keys(localStorage)
        .filter((k) => k.startsWith(base + prefix))
        .map((k) => k.slice(base.length));
      return { keys, prefix, shared };
    },
  };
}
