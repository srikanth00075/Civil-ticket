import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  ThumbsUp,
  MessageCircle,
  Send,
  Plus,
  ClipboardList,
  Map as MapIcon,
  ShieldCheck,
  X,
  Camera,
  Search,
  Lock,
  AlertTriangle,
  BarChart3,
  Loader2,
  Flag,
  Star,
  Download,
  UserCircle,
  RefreshCw,
} from "lucide-react";

const CATEGORIES = [
  { id: "roads", label: "Roads & Potholes" },
  { id: "sanitation", label: "Sanitation" },
  { id: "lighting", label: "Street Lighting" },
  { id: "water", label: "Water Supply" },
  { id: "parks", label: "Parks & Public Space" },
  { id: "other", label: "Other" },
];

const STATUS = {
  open: { label: "OPEN", color: "var(--stamp-orange)" },
  progress: { label: "IN PROGRESS", color: "var(--stamp-amber)" },
  resolved: { label: "RESOLVED", color: "var(--stamp-green)" },
};

const STORAGE_KEYS = {
  complaints: "civic-ticket:complaints",
  myReports: "civic-ticket:my-reports",
};

const ADMIN_PASSCODE = "WARD14";
const DAY = 86400000;
const NOW = Date.now();

// Days-open thresholds per category, tuned to how urgent each issue type usually is:
// [due for review, escalate to ward officer, escalate to commissioner]
const CATEGORY_SLA = {
  water: [1, 3, 6],
  lighting: [2, 5, 10],
  roads: [3, 7, 14],
  sanitation: [2, 5, 10],
  parks: [5, 10, 20],
  other: [3, 7, 14],
};
const ESCALATION_LABELS = [
  { label: "Due for review", color: "var(--ink-soft)" },
  { label: "Escalated to ward officer", color: "var(--stamp-amber)" },
  { label: "Escalated to commissioner", color: "var(--stamp-orange)" },
];

function getEscalation(ts, status, category) {
  if (status === "resolved" || !ts) return null;
  const ageDays = (Date.now() - ts) / DAY;
  const thresholds = CATEGORY_SLA[category] || CATEGORY_SLA.other;
  for (let i = thresholds.length - 1; i >= 0; i--) {
    if (ageDays >= thresholds[i]) {
      return { ...ESCALATION_LABELS[i], ageDays: Math.floor(ageDays) };
    }
  }
  return null;
}

const OFFICERS = [
  "R. Iyer — Roads & Water",
  "K. Suresh — Sanitation",
  "M. Devi — Lighting & Parks",
  "A. Krishnan — General",
];

// Escalation tier (0–3) plus upvotes gives a rough triage order for staff:
// long-overdue, well-supported issues should be worked before quiet, fresh ones.
function priorityScore(c) {
  if (c.status === "resolved") return -1;
  const esc = getEscalation(c.ts, c.status, c.category);
  const tierWeight = esc ? ESCALATION_LABELS.findIndex((t) => t.label === esc.label) + 1 : 0;
  return tierWeight * 25 + c.upvotes;
}

const seedComplaints = [
  {
    id: "TCK-1042",
    title: "Deep pothole near bus stop",
    description:
      "Large pothole has formed right where commuters wait for the bus. Two-wheelers keep swerving into traffic to avoid it.",
    category: "roads",
    status: "open",
    x: 32,
    y: 44,
    photo:
      "https://images.unsplash.com/photo-1591192398084-6cc16d20e0e3?w=500&auto=format&fit=crop&q=60",
    upvotes: 14,
    upvotedByMe: false,
    createdAt: "2 days ago",
    ts: NOW - 2 * DAY,
    comments: [{ author: "R. Menon", text: "Same here, nearly hit it in the dark." }],
  },
  {
    id: "TCK-1039",
    title: "Overflowing garbage bin, MG Road",
    description:
      "Bin hasn't been cleared in over a week. Attracting stray dogs and smell is bad near the market entrance.",
    category: "sanitation",
    status: "progress",
    x: 61,
    y: 58,
    upvotes: 27,
    upvotedByMe: true,
    createdAt: "4 days ago",
    ts: NOW - 4 * DAY,
    comments: [
      { author: "Ward Office", text: "Extra collection scheduled for this week." },
      { author: "S. Patel", text: "Still waiting, please expedite." },
    ],
  },
  {
    id: "TCK-1031",
    title: "Broken streetlight, Park Avenue",
    description:
      "Streetlight outside the park entrance has been dark for two weeks. Area feels unsafe after 8pm.",
    category: "lighting",
    status: "resolved",
    x: 74,
    y: 30,
    upvotes: 9,
    upvotedByMe: false,
    createdAt: "9 days ago",
    ts: NOW - 9 * DAY,
    comments: [],
  },
];

function timeAgo(ts) {
  const diff = Date.now() - ts;
  if (diff < 60000) return "just now";
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
}

function StampBadge({ status }) {
  const s = STATUS[status];
  return (
    <div className="stamp" style={{ "--stamp-color": s.color }}>
      {s.label}
    </div>
  );
}

function StarRating({ value, onRate, interactive }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="star-row">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          className="star-btn"
          disabled={!interactive}
          onClick={() => interactive && onRate(n)}
          onMouseEnter={() => interactive && setHover(n)}
          onMouseLeave={() => interactive && setHover(0)}
          aria-label={`Rate ${n} star${n === 1 ? "" : "s"}`}
        >
          <Star size={16} fill={(hover || value) >= n ? "currentColor" : "none"} />
        </button>
      ))}
    </div>
  );
}

function TicketStub({ complaint, mine, onUpvote, onComment, onOpenPhoto, onRate }) {
  const [showComments, setShowComments] = useState(false);
  const [draft, setDraft] = useState("");
  const cat = CATEGORIES.find((c) => c.id === complaint.category);
  const escalation = getEscalation(complaint.ts, complaint.status, complaint.category);
  const resolvedDays =
    complaint.status === "resolved" && complaint.resolvedAt && complaint.ts
      ? Math.max(1, Math.round((complaint.resolvedAt - complaint.ts) / DAY))
      : null;

  return (
    <div className="ticket">
      <div className="ticket-main">
        <div className="ticket-head">
          <span className="ticket-id">
            {complaint.id}
            {mine && <span className="mine-tag">Filed by you</span>}
          </span>
          <span className="ticket-cat">{cat ? cat.label : "Other"}</span>
        </div>
        <h3 className="ticket-title">{complaint.title}</h3>
        {escalation && (
          <div className="escalation-badge" style={{ "--esc-color": escalation.color }}>
            <Flag size={12} />
            {escalation.label} · open {escalation.ageDays} day{escalation.ageDays === 1 ? "" : "s"}
          </div>
        )}
        {complaint.assignedTo && complaint.status !== "resolved" && (
          <div className="assigned-tag">
            <UserCircle size={12} />
            Assigned to {complaint.assignedTo}
          </div>
        )}
        {complaint.photo && !complaint.resolvedPhoto && (
          <img
            className="ticket-photo"
            src={complaint.photo}
            alt={`Photo attached to ${complaint.id}`}
            onClick={() => onOpenPhoto(complaint.photo, complaint.title)}
          />
        )}
        {complaint.photo && complaint.resolvedPhoto && (
          <div className="before-after">
            <div className="before-after-col">
              <img
                src={complaint.photo}
                alt={`Before photo for ${complaint.id}`}
                onClick={() => onOpenPhoto(complaint.photo, `${complaint.title} — before`)}
              />
              <span>Before</span>
            </div>
            <div className="before-after-col">
              <img
                src={complaint.resolvedPhoto}
                alt={`After photo for ${complaint.id}`}
                onClick={() => onOpenPhoto(complaint.resolvedPhoto, `${complaint.title} — after`)}
              />
              <span>After</span>
            </div>
          </div>
        )}
        <p className="ticket-desc">{complaint.description}</p>
        <div className="ticket-foot">
          <span className="ticket-time">
            Filed {complaint.ts ? timeAgo(complaint.ts) : complaint.createdAt}
          </span>
          <div className="ticket-actions">
            <button
              className={`pill-btn ${complaint.upvotedByMe ? "pill-btn-active" : ""}`}
              onClick={() => onUpvote(complaint.id)}
            >
              <ThumbsUp size={14} strokeWidth={2.2} />
              {complaint.upvotes}
            </button>
            <button className="pill-btn" onClick={() => setShowComments((v) => !v)}>
              <MessageCircle size={14} strokeWidth={2.2} />
              {complaint.comments.length}
            </button>
          </div>
        </div>

        {resolvedDays !== null && (
          <div className="resolved-note">
            Resolved in {resolvedDays} day{resolvedDays === 1 ? "" : "s"}
            {complaint.rating ? (
              <span className="resolved-rating">
                <StarRating value={complaint.rating} interactive={false} />
              </span>
            ) : mine ? (
              <span className="resolved-rating">
                Rate this: <StarRating value={0} interactive onRate={(n) => onRate(complaint.id, n)} />
              </span>
            ) : (
              <span className="resolved-rating-pending">Awaiting citizen rating</span>
            )}
          </div>
        )}

        {showComments && (
          <div className="comments">
            {complaint.comments.length === 0 && (
              <p className="comments-empty">No comments yet. Be the first to add context.</p>
            )}
            {complaint.comments.map((c, i) => (
              <div className="comment" key={i}>
                <span className="comment-author">{c.author}</span>
                <span className="comment-text">{c.text}</span>
              </div>
            ))}
            <form
              className="comment-form"
              onSubmit={(e) => {
                e.preventDefault();
                if (!draft.trim()) return;
                onComment(complaint.id, draft.trim());
                setDraft("");
              }}
            >
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="Add a comment..."
              />
              <button type="submit" aria-label="Send comment">
                <Send size={14} />
              </button>
            </form>
          </div>
        )}
      </div>
      <div className="ticket-stub">
        <StampBadge status={complaint.status} />
      </div>
    </div>
  );
}

function TownMap({ complaints, onPick, pickable, pendingPin }) {
  const svgRef = useRef(null);

  const handleClick = (e) => {
    if (!pickable || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    onPick({ x: Math.round(x), y: Math.round(y) });
  };

  return (
    <div className="map-wrap">
      <svg
        ref={svgRef}
        viewBox="0 0 100 70"
        className={`map-svg ${pickable ? "map-pickable" : ""}`}
        onClick={handleClick}
      >
        <rect x="0" y="0" width="100" height="70" fill="var(--paper-dark)" />
        {[10, 25, 40, 55, 70, 85].map((x) => (
          <line key={"v" + x} x1={x} y1="0" x2={x} y2="70" stroke="var(--line)" strokeWidth="0.6" />
        ))}
        {[10, 22, 34, 46, 58].map((y) => (
          <line key={"h" + y} x1="0" y1={y} x2="100" y2={y} stroke="var(--line)" strokeWidth="0.6" />
        ))}
        <rect x="14" y="14" width="18" height="12" fill="var(--paper)" opacity="0.6" />
        <rect x="46" y="30" width="22" height="16" fill="var(--paper)" opacity="0.6" />
        <rect x="72" y="10" width="16" height="14" fill="var(--paper)" opacity="0.6" />
        <text x="3" y="6" className="map-label">
          MAIN ST
        </text>
        {complaints.map((c) => (
          <g key={c.id} transform={`translate(${c.x * 1}, ${c.y * 0.7})`}>
            <circle r="2.2" fill={STATUS[c.status].color} stroke="var(--ink)" strokeWidth="0.4" />
          </g>
        ))}
        {pendingPin && (
          <g transform={`translate(${pendingPin.x}, ${pendingPin.y * 0.7})`}>
            <circle r="2.6" fill="var(--ink)" />
            <circle r="4.4" fill="none" stroke="var(--ink)" strokeWidth="0.5" />
          </g>
        )}
      </svg>
      {pickable && <p className="map-hint">Click the map to mark the location</p>}
    </div>
  );
}

function dailyTrend(complaints, days) {
  const buckets = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  for (let i = days - 1; i >= 0; i--) {
    const start = today.getTime() - i * DAY;
    const end = start + DAY;
    const count = complaints.filter((c) => c.ts && c.ts >= start && c.ts < end).length;
    const d = new Date(start);
    buckets.push({ label: `${d.getDate()}/${d.getMonth() + 1}`, count });
  }
  return buckets;
}

function Ledger({ complaints }) {
  const total = complaints.length;
  const resolved = complaints.filter((c) => c.status === "resolved").length;
  const resolutionRate = total ? Math.round((resolved / total) * 100) : 0;
  const totalUpvotes = complaints.reduce((s, c) => s + c.upvotes, 0);
  const overdue = complaints.filter((c) => getEscalation(c.ts, c.status, c.category)).length;

  const resolvedWithTimes = complaints.filter((c) => c.status === "resolved" && c.resolvedAt && c.ts);
  const avgResolutionDays = resolvedWithTimes.length
    ? Math.round(resolvedWithTimes.reduce((s, c) => s + (c.resolvedAt - c.ts) / DAY, 0) / resolvedWithTimes.length)
    : null;

  const rated = complaints.filter((c) => c.rating);
  const avgRating = rated.length ? (rated.reduce((s, c) => s + c.rating, 0) / rated.length).toFixed(1) : null;

  const trend = dailyTrend(complaints, 14);
  const maxTrend = Math.max(1, ...trend.map((t) => t.count));

  const byCategory = CATEGORIES.map((cat) => ({
    ...cat,
    count: complaints.filter((c) => c.category === cat.id).length,
  })).sort((a, b) => b.count - a.count);
  const maxCat = Math.max(1, ...byCategory.map((c) => c.count));

  const byStatus = Object.keys(STATUS).map((key) => ({
    key,
    ...STATUS[key],
    count: complaints.filter((c) => c.status === key).length,
  }));
  const maxStatus = Math.max(1, ...byStatus.map((s) => s.count));

  const topUpvoted = [...complaints].sort((a, b) => b.upvotes - a.upvotes).slice(0, 3);

  return (
    <div className="ledger">
      <div className="ledger-summary">
        <div className="ledger-stat">
          <span className="ledger-stat-num">{total}</span>
          <span className="ledger-stat-label">Total filed</span>
        </div>
        <div className="ledger-stat">
          <span className="ledger-stat-num">{resolutionRate}%</span>
          <span className="ledger-stat-label">Resolved</span>
        </div>
        <div className="ledger-stat">
          <span className="ledger-stat-num">{totalUpvotes}</span>
          <span className="ledger-stat-label">Total upvotes</span>
        </div>
        <div className="ledger-stat ledger-stat-warn">
          <span className="ledger-stat-num">{overdue}</span>
          <span className="ledger-stat-label">Overdue</span>
        </div>
        <div className="ledger-stat">
          <span className="ledger-stat-num">{avgResolutionDays !== null ? avgResolutionDays : "–"}</span>
          <span className="ledger-stat-label">Avg days to resolve</span>
        </div>
        <div className="ledger-stat">
          <span className="ledger-stat-num">{avgRating !== null ? `${avgRating}★` : "–"}</span>
          <span className="ledger-stat-label">Citizen satisfaction</span>
        </div>
      </div>

      <div className="ledger-card">
        <h4 className="ledger-card-title">Filed over the last 14 days</h4>
        <div className="trend-row">
          {trend.map((t, i) => (
            <div className="trend-col" key={i}>
              <span className="trend-count">{t.count || ""}</span>
              <div
                className="trend-bar"
                style={{ height: `${Math.max(4, (t.count / maxTrend) * 60)}px` }}
              />
              <span className="trend-label">{t.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="ledger-card">
        <h4 className="ledger-card-title">By category</h4>
        {byCategory.map((c) => (
          <div className="bar-row" key={c.id}>
            <span className="bar-label">{c.label}</span>
            <div className="bar-track">
              <div className="bar-fill" style={{ width: `${(c.count / maxCat) * 100}%` }} />
            </div>
            <span className="bar-count">{c.count}</span>
          </div>
        ))}
      </div>

      <div className="ledger-card">
        <h4 className="ledger-card-title">By status</h4>
        {byStatus.map((s) => (
          <div className="bar-row" key={s.key}>
            <span className="bar-label">{s.label}</span>
            <div className="bar-track">
              <div
                className="bar-fill"
                style={{ width: `${(s.count / maxStatus) * 100}%`, background: s.color }}
              />
            </div>
            <span className="bar-count">{s.count}</span>
          </div>
        ))}
      </div>

      <div className="ledger-card">
        <h4 className="ledger-card-title">Most upvoted</h4>
        {topUpvoted.length === 0 && <p className="comments-empty">No complaints yet.</p>}
        {topUpvoted.map((c, i) => (
          <div className="top-row" key={c.id}>
            <span className="top-rank">{i + 1}</span>
            <span className="top-title">{c.title}</span>
            <span className="top-votes">
              <ThumbsUp size={12} /> {c.upvotes}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function CivicComplaintPortal() {
  const [loading, setLoading] = useState(true);
  const [complaints, setComplaints] = useState(seedComplaints);
  const [myReportIds, setMyReportIds] = useState([]);
  const [tab, setTab] = useState("board");
  const [boardView, setBoardView] = useState("list");
  const [filterCat, setFilterCat] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [onlyMine, setOnlyMine] = useState(false);
  const [query, setQuery] = useState("");
  const [sortBy, setSortBy] = useState("recent");

  const [form, setForm] = useState({ title: "", category: "roads", description: "", photo: null });
  const [pin, setPin] = useState(null);
  const [submitted, setSubmitted] = useState(null);
  const [photoError, setPhotoError] = useState("");
  const [dismissedDup, setDismissedDup] = useState(false);

  const [lightbox, setLightbox] = useState(null);
  const [toast, setToast] = useState(null);

  const [adminUnlocked, setAdminUnlocked] = useState(false);
  const [passcodeInput, setPasscodeInput] = useState("");
  const [passcodeError, setPasscodeError] = useState("");
  const [adminSort, setAdminSort] = useState("priority");

  const [hasRemoteUpdate, setHasRemoteUpdate] = useState(false);
  const complaintsRef = useRef(complaints);
  const remoteRef = useRef(null);

  useEffect(() => {
    complaintsRef.current = complaints;
  }, [complaints]);

  useEffect(() => {
    if (loading) return;
    const poll = setInterval(async () => {
      try {
        const res = await window.storage.get(STORAGE_KEYS.complaints, true);
        if (res && res.value && res.value !== JSON.stringify(complaintsRef.current)) {
          remoteRef.current = JSON.parse(res.value);
          setHasRemoteUpdate(true);
        }
      } catch (err) {
        // storage temporarily unreachable — try again next tick
      }
    }, 20000);
    return () => clearInterval(poll);
  }, [loading]);

  const applyRemoteUpdate = () => {
    if (remoteRef.current) {
      setComplaints(remoteRef.current);
      remoteRef.current = null;
    }
    setHasRemoteUpdate(false);
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await window.storage.get(STORAGE_KEYS.complaints, true);
        if (!cancelled && res && res.value) {
          setComplaints(JSON.parse(res.value));
        } else if (!cancelled) {
          setComplaints(seedComplaints);
          window.storage.set(STORAGE_KEYS.complaints, JSON.stringify(seedComplaints), true).catch(() => {});
        }
      } catch (err) {
        if (!cancelled) {
          setComplaints(seedComplaints);
          window.storage.set(STORAGE_KEYS.complaints, JSON.stringify(seedComplaints), true).catch(() => {});
        }
      }
      try {
        const mine = await window.storage.get(STORAGE_KEYS.myReports, false);
        if (!cancelled && mine && mine.value) setMyReportIds(JSON.parse(mine.value));
      } catch (err) {
        // no personal reports saved yet
      }
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3200);
    return () => clearTimeout(t);
  }, [toast]);

  useEffect(() => {
    if (!lightbox) return;
    const onKey = (e) => {
      if (e.key === "Escape") setLightbox(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightbox]);

  const persistComplaints = (next) => {
    setComplaints(next);
    window.storage.set(STORAGE_KEYS.complaints, JSON.stringify(next), true).catch(() => {
      setToast({ kind: "error", text: "Couldn't save — check your connection and try again." });
    });
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setPhotoError("Please choose an image file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setPhotoError("Image is too large — please choose one under 5MB.");
      return;
    }
    setPhotoError("");
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, photo: reader.result }));
    reader.readAsDataURL(file);
  };

  const handleUpvote = (id) => {
    const next = complaints.map((c) =>
      c.id === id
        ? { ...c, upvotedByMe: !c.upvotedByMe, upvotes: c.upvotedByMe ? c.upvotes - 1 : c.upvotes + 1 }
        : c
    );
    persistComplaints(next);
  };

  const handleComment = (id, text) => {
    const next = complaints.map((c) =>
      c.id === id ? { ...c, comments: [...c.comments, { author: "You", text }] } : c
    );
    persistComplaints(next);
  };

  const handleStatusChange = (id, status) => {
    const next = complaints.map((c) =>
      c.id === id ? { ...c, status, resolvedAt: status === "resolved" ? Date.now() : undefined } : c
    );
    persistComplaints(next);
    setToast({ kind: "ok", text: `${id} marked ${STATUS[status].label.toLowerCase()}.` });
  };

  const handleAssign = (id, officer) => {
    const next = complaints.map((c) => (c.id === id ? { ...c, assignedTo: officer || null } : c));
    persistComplaints(next);
  };

  const handleAddProof = (id, dataUrl) => {
    const next = complaints.map((c) => (c.id === id ? { ...c, resolvedPhoto: dataUrl } : c));
    persistComplaints(next);
    setToast({ kind: "ok", text: "Resolution photo added — visible on the public board." });
  };

  const handleRate = (id, rating) => {
    const next = complaints.map((c) => (c.id === id ? { ...c, rating } : c));
    persistComplaints(next);
    setToast({ kind: "ok", text: "Thanks — your rating helps the ward office prioritize." });
  };

  const nearbyDuplicate = useMemo(() => {
    if (!pin) return null;
    return (
      complaints.find(
        (c) =>
          c.category === form.category &&
          c.status !== "resolved" &&
          Math.hypot(c.x - pin.x, c.y - pin.y) < 8
      ) || null
    );
  }, [pin, form.category, complaints]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.description.trim() || !pin) return;
    const id = "TCK-" + (1000 + Math.floor(Math.random() * 9000));
    const newComplaint = {
      id,
      title: form.title.trim(),
      description: form.description.trim(),
      category: form.category,
      status: "open",
      x: pin.x,
      y: pin.y,
      photo: form.photo,
      upvotes: 0,
      upvotedByMe: false,
      createdAt: "just now",
      ts: Date.now(),
      comments: [],
    };
    persistComplaints([newComplaint, ...complaints]);
    const nextMine = [...myReportIds, id];
    setMyReportIds(nextMine);
    window.storage.set(STORAGE_KEYS.myReports, JSON.stringify(nextMine), false).catch(() => {});
    setSubmitted(id);
    setForm({ title: "", category: "roads", description: "", photo: null });
    setPin(null);
    setDismissedDup(false);
  };

  const handleUpvoteDuplicate = () => {
    if (!nearbyDuplicate) return;
    handleUpvote(nearbyDuplicate.id);
    setToast({ kind: "ok", text: `Upvoted ${nearbyDuplicate.id} instead of filing a duplicate.` });
    setForm({ title: "", category: "roads", description: "", photo: null });
    setPin(null);
    setDismissedDup(false);
    setTab("board");
  };

  const handlePasscodeSubmit = (e) => {
    e.preventDefault();
    if (passcodeInput.trim().toUpperCase() === ADMIN_PASSCODE) {
      setAdminUnlocked(true);
      setPasscodeError("");
    } else {
      setPasscodeError("Incorrect passcode. Try again.");
    }
  };

  const csvField = (v) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };

  const handleExportCSV = () => {
    const headers = ["ID", "Title", "Category", "Status", "Upvotes", "Comments", "Days open", "Escalation", "Rating"];
    const rows = complaints.map((c) => {
      const esc = getEscalation(c.ts, c.status, c.category);
      const daysOpen = c.ts ? Math.floor((Date.now() - c.ts) / DAY) : "";
      return [
        c.id,
        c.title,
        CATEGORIES.find((x) => x.id === c.category)?.label || c.category,
        STATUS[c.status]?.label || c.status,
        c.upvotes,
        c.comments.length,
        daysOpen,
        esc ? esc.label : "",
        c.rating || "",
      ];
    });
    const csv = [headers, ...rows].map((r) => r.map(csvField).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `civic-ticket-export-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setToast({ kind: "ok", text: "CSV exported." });
  };

  const filtered = useMemo(() => {
    let list = complaints.filter(
      (c) =>
        (filterCat === "all" || c.category === filterCat) &&
        (filterStatus === "all" || c.status === filterStatus) &&
        (!onlyMine || myReportIds.includes(c.id))
    );
    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (c) => c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q)
      );
    }
    list = [...list].sort((a, b) => {
      if (sortBy === "top") return b.upvotes - a.upvotes;
      if (sortBy === "oldest") return (a.ts || 0) - (b.ts || 0);
      return (b.ts || 0) - (a.ts || 0);
    });
    return list;
  }, [complaints, filterCat, filterStatus, onlyMine, myReportIds, query, sortBy]);

  const counts = {
    open: complaints.filter((c) => c.status === "open").length,
    progress: complaints.filter((c) => c.status === "progress").length,
    resolved: complaints.filter((c) => c.status === "resolved").length,
  };

  return (
    <div className="app">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=JetBrains+Mono:wght@400;500&display=swap');

        .app {
          --paper: #F3EFE3;
          --paper-dark: #EAE3D2;
          --ink: #1F2A44;
          --ink-soft: #3A4562;
          --muted: #74705F;
          --line: #C9C0AA;
          --stamp-orange: #C1501F;
          --stamp-amber: #A8791F;
          --stamp-green: #3E6B49;
          font-family: 'Source Serif 4', Georgia, serif;
          background: var(--paper);
          color: var(--ink);
          min-height: 100%;
          padding: 0;
          position: relative;
        }
        .app * { box-sizing: border-box; }

        .header {
          background: var(--ink);
          color: var(--paper);
          padding: 20px 24px 16px;
          border-bottom: 4px solid var(--stamp-orange);
        }
        .header-top { display: flex; align-items: center; justify-content: space-between; }
        .header-title {
          font-family: 'Oswald', sans-serif;
          font-weight: 600;
          letter-spacing: 0.04em;
          font-size: 22px;
          text-transform: uppercase;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .header-sub {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          opacity: 0.65;
          margin-top: 4px;
          letter-spacing: 0.03em;
        }
        .header-stats {
          display: flex;
          gap: 16px;
          margin-top: 14px;
          flex-wrap: wrap;
        }
        .stat {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          border: 1px solid rgba(243,239,227,0.3);
          border-radius: 3px;
          padding: 4px 10px;
          letter-spacing: 0.03em;
        }

        .tabs {
          display: flex;
          background: var(--paper-dark);
          border-bottom: 1px solid var(--line);
          padding: 0 24px;
          gap: 4px;
          overflow-x: auto;
        }
        .tab-btn {
          font-family: 'Oswald', sans-serif;
          text-transform: uppercase;
          font-size: 12.5px;
          letter-spacing: 0.05em;
          padding: 12px 16px 10px;
          background: none;
          border: none;
          color: var(--muted);
          cursor: pointer;
          border-bottom: 3px solid transparent;
          display: flex;
          align-items: center;
          gap: 6px;
          white-space: nowrap;
        }
        .tab-btn.active {
          color: var(--ink);
          border-bottom-color: var(--stamp-orange);
        }
        .tab-btn:hover { color: var(--ink); }

        .content { padding: 22px 24px 40px; max-width: 780px; margin: 0 auto; }

        .loading-state {
          display: flex;
          align-items: center;
          gap: 10px;
          justify-content: center;
          padding: 60px 0;
          color: var(--muted);
          font-family: 'JetBrains Mono', monospace;
          font-size: 12.5px;
        }
        .sync-banner {
          display: flex;
          align-items: center;
          gap: 8px;
          width: 100%;
          justify-content: center;
          background: var(--paper-dark);
          border: 1px dashed var(--ink-soft);
          color: var(--ink-soft);
          border-radius: 3px;
          padding: 9px 12px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 12px;
          cursor: pointer;
          margin-bottom: 16px;
        }
        .sync-banner:hover { background: #fff; }
        .spin { animation: spin 0.9s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* Ticket stub */
        .ticket {
          display: flex;
          background: #fff;
          border: 1px solid var(--line);
          border-radius: 2px;
          margin-bottom: 16px;
          box-shadow: 0 1px 0 rgba(31,42,68,0.04);
          position: relative;
          overflow: hidden;
        }
        .ticket-main { flex: 1; padding: 16px 18px; min-width: 0; }
        .ticket-head {
          display: flex; justify-content: space-between; align-items: center;
          font-family: 'JetBrains Mono', monospace;
          font-size: 10.5px;
          color: var(--muted);
          letter-spacing: 0.03em;
          margin-bottom: 8px;
          gap: 8px;
        }
        .ticket-id { font-weight: 500; color: var(--ink-soft); display: flex; align-items: center; gap: 8px; }
        .mine-tag {
          background: var(--ink);
          color: var(--paper);
          padding: 2px 6px;
          border-radius: 2px;
          font-size: 9.5px;
          letter-spacing: 0.03em;
        }
        .ticket-cat {
          background: var(--paper-dark);
          padding: 2px 7px;
          border-radius: 2px;
          text-transform: uppercase;
          white-space: nowrap;
        }
        .ticket-title {
          font-family: 'Oswald', sans-serif;
          font-size: 17px;
          font-weight: 500;
          margin: 0 0 6px;
          color: var(--ink);
        }
        .ticket-photo {
          width: 100%;
          max-height: 220px;
          object-fit: cover;
          border: 1px solid var(--line);
          border-radius: 2px;
          margin-bottom: 10px;
          display: block;
          cursor: zoom-in;
        }
        .ticket-desc {
          font-size: 14px;
          line-height: 1.5;
          color: var(--ink-soft);
          margin: 0 0 12px;
        }
        .escalation-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 10.5px;
          color: var(--esc-color);
          border: 1px solid var(--esc-color);
          border-radius: 3px;
          padding: 3px 7px;
          margin-bottom: 10px;
          letter-spacing: 0.02em;
        }
        .assigned-tag {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 10.5px;
          color: var(--ink-soft);
          background: var(--paper-dark);
          border-radius: 3px;
          padding: 3px 7px;
          margin-bottom: 10px;
          margin-left: 6px;
        }
        .before-after { display: flex; gap: 8px; margin-bottom: 10px; }
        .before-after-col { flex: 1; text-align: center; }
        .before-after-col img {
          width: 100%;
          height: 120px;
          object-fit: cover;
          border: 1px solid var(--line);
          border-radius: 2px;
          display: block;
          cursor: zoom-in;
        }
        .before-after-col span {
          display: block;
          font-family: 'JetBrains Mono', monospace;
          font-size: 10px;
          color: var(--muted);
          margin-top: 3px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .resolved-note {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 8px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          color: var(--stamp-green);
          border-top: 1px dashed var(--line);
          padding-top: 10px;
          margin-top: 10px;
        }
        .resolved-rating { display: flex; align-items: center; gap: 4px; color: var(--muted); }
        .resolved-rating-pending { color: var(--muted); font-style: italic; }
        .star-row { display: flex; gap: 2px; }
        .star-btn { background: none; border: none; padding: 0; cursor: pointer; color: var(--stamp-amber); display: flex; }
        .star-btn:disabled { cursor: default; }
        .ticket-foot {
          display: flex; justify-content: space-between; align-items: center;
          border-top: 1px dashed var(--line);
          padding-top: 10px;
          gap: 8px;
        }
        .ticket-time { font-size: 11px; color: var(--muted); font-family: 'JetBrains Mono', monospace; }
        .ticket-actions { display: flex; gap: 8px; }

        .pill-btn {
          display: flex; align-items: center; gap: 5px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 11.5px;
          background: var(--paper);
          border: 1px solid var(--line);
          border-radius: 20px;
          padding: 5px 10px;
          cursor: pointer;
          color: var(--ink-soft);
        }
        .pill-btn:hover { border-color: var(--ink-soft); }
        .pill-btn-active {
          background: var(--ink);
          color: var(--paper);
          border-color: var(--ink);
        }

        .ticket-stub {
          width: 86px;
          background: var(--paper-dark);
          border-left: 2px dashed var(--line);
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
          flex-shrink: 0;
        }
        .ticket-stub::before, .ticket-stub::after {
          content: '';
          position: absolute;
          width: 14px; height: 14px;
          background: var(--paper);
          border-radius: 50%;
          left: -8px;
        }
        .ticket-stub::before { top: -7px; }
        .ticket-stub::after { bottom: -7px; }

        .stamp {
          font-family: 'Oswald', sans-serif;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.05em;
          color: var(--stamp-color);
          border: 2px solid var(--stamp-color);
          border-radius: 4px;
          padding: 5px 6px;
          transform: rotate(-8deg);
          text-align: center;
          line-height: 1.2;
        }

        .comments { margin-top: 12px; border-top: 1px solid var(--line); padding-top: 10px; }
        .comments-empty { font-size: 12.5px; color: var(--muted); font-style: italic; margin: 0 0 8px; }
        .comment { font-size: 13px; margin-bottom: 6px; }
        .comment-author { font-weight: 600; color: var(--ink-soft); margin-right: 6px; font-family: 'Oswald', sans-serif; font-size: 12px; }
        .comment-text { color: var(--ink); }
        .comment-form { display: flex; gap: 6px; margin-top: 8px; }
        .comment-form input {
          flex: 1;
          border: 1px solid var(--line);
          border-radius: 3px;
          padding: 7px 9px;
          font-family: 'Source Serif 4', serif;
          font-size: 13px;
          background: var(--paper);
        }
        .comment-form button {
          background: var(--ink);
          color: var(--paper);
          border: none;
          border-radius: 3px;
          padding: 0 12px;
          cursor: pointer;
        }

        /* filters */
        .filters { display: flex; gap: 8px; margin-bottom: 12px; flex-wrap: wrap; align-items: center; }
        .filters select {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11.5px;
          padding: 6px 8px;
          border: 1px solid var(--line);
          border-radius: 3px;
          background: #fff;
          color: var(--ink-soft);
        }
        .search-box {
          display: flex;
          align-items: center;
          gap: 6px;
          border: 1px solid var(--line);
          border-radius: 3px;
          background: #fff;
          padding: 6px 9px;
          flex: 1;
          min-width: 160px;
        }
        .search-box input {
          border: none;
          outline: none;
          background: none;
          font-family: 'Source Serif 4', serif;
          font-size: 13px;
          flex: 1;
          color: var(--ink);
        }
        .search-box svg { color: var(--muted); flex-shrink: 0; }
        .mine-toggle {
          display: flex;
          align-items: center;
          gap: 6px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          color: var(--ink-soft);
          cursor: pointer;
          border: 1px solid var(--line);
          background: #fff;
          border-radius: 3px;
          padding: 6px 9px;
        }
        .mine-toggle input { accent-color: var(--ink); }
        .view-toggle { display: flex; gap: 4px; margin-left: auto; }
        .view-toggle button {
          border: 1px solid var(--line);
          background: #fff;
          padding: 6px 10px;
          border-radius: 3px;
          cursor: pointer;
          display: flex; align-items: center; gap: 5px;
          font-size: 11.5px;
          font-family: 'JetBrains Mono', monospace;
          color: var(--muted);
        }
        .view-toggle button.active { background: var(--ink); color: var(--paper); border-color: var(--ink); }

        /* map */
        .map-wrap { margin-bottom: 16px; }
        .map-svg {
          width: 100%;
          height: auto;
          border: 1px solid var(--line);
          border-radius: 3px;
          background: var(--paper-dark);
        }
        .map-pickable { cursor: crosshair; }
        .map-label {
          font-family: 'JetBrains Mono', monospace;
          font-size: 2.6px;
          fill: var(--muted);
          letter-spacing: 0.05em;
        }
        .map-hint { font-size: 11.5px; color: var(--muted); font-family: 'JetBrains Mono', monospace; margin-top: 6px; }
        .map-legend { display: flex; gap: 14px; font-size: 11px; font-family: 'JetBrains Mono', monospace; color: var(--muted); margin-top: 8px; margin-bottom: 16px; }
        .map-legend span { display: flex; align-items: center; gap: 5px; }
        .legend-dot { width: 9px; height: 9px; border-radius: 50%; display: inline-block; }

        /* duplicate warning */
        .dup-note {
          display: flex;
          gap: 10px;
          align-items: flex-start;
          background: #FBF3E4;
          border: 1px solid var(--stamp-amber);
          border-radius: 3px;
          padding: 12px 14px;
          margin-bottom: 16px;
        }
        .dup-note svg { color: var(--stamp-amber); flex-shrink: 0; margin-top: 2px; }
        .dup-note-title { font-family: 'Oswald', sans-serif; font-size: 13px; color: var(--ink); margin: 0 0 3px; }
        .dup-note-text { font-size: 13px; color: var(--ink-soft); margin: 0 0 8px; line-height: 1.4; }
        .dup-note-actions { display: flex; gap: 8px; }
        .dup-btn {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px;
          border-radius: 3px;
          padding: 6px 10px;
          cursor: pointer;
          border: 1px solid var(--stamp-amber);
        }
        .dup-btn-primary { background: var(--stamp-amber); color: #fff; }
        .dup-btn-secondary { background: none; color: var(--ink-soft); border-color: var(--line); }

        /* form */
        .form-card {
          background: #fff;
          border: 1px solid var(--line);
          border-radius: 3px;
          padding: 20px;
        }
        .field { margin-bottom: 16px; }
        .field label {
          display: block;
          font-family: 'Oswald', sans-serif;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: var(--ink-soft);
          margin-bottom: 6px;
        }
        .field input, .field textarea, .field select {
          width: 100%;
          border: 1px solid var(--line);
          border-radius: 3px;
          padding: 9px 10px;
          font-family: 'Source Serif 4', serif;
          font-size: 14px;
          background: var(--paper);
          color: var(--ink);
        }
        .field textarea { resize: vertical; min-height: 80px; }
        .photo-upload {
          display: flex;
          align-items: center;
          gap: 8px;
          border: 1px dashed var(--line);
          border-radius: 3px;
          padding: 14px 12px;
          cursor: pointer;
          color: var(--muted);
          font-size: 13px;
          background: var(--paper);
        }
        .photo-upload:hover { border-color: var(--ink-soft); color: var(--ink-soft); }
        .photo-upload input { display: none; }
        .photo-preview {
          position: relative;
          border: 1px solid var(--line);
          border-radius: 3px;
          overflow: hidden;
          width: 160px;
        }
        .photo-preview img { width: 100%; height: 120px; object-fit: cover; display: block; }
        .photo-remove {
          display: flex;
          align-items: center;
          gap: 4px;
          width: 100%;
          justify-content: center;
          border: none;
          background: var(--ink);
          color: var(--paper);
          font-size: 11px;
          font-family: 'JetBrains Mono', monospace;
          padding: 6px 0;
          cursor: pointer;
        }
        .photo-error { color: var(--stamp-orange); font-size: 11.5px; margin-top: 6px; font-family: 'JetBrains Mono', monospace; }
        .submit-btn {
          font-family: 'Oswald', sans-serif;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          font-size: 13px;
          background: var(--stamp-orange);
          color: #fff;
          border: none;
          border-radius: 3px;
          padding: 11px 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .submit-btn:disabled { opacity: 0.4; cursor: not-allowed; }
        .success-banner {
          background: var(--stamp-green);
          color: #fff;
          padding: 10px 14px;
          border-radius: 3px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 12.5px;
          margin-bottom: 16px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .success-banner button { background: none; border: none; color: #fff; cursor: pointer; }

        /* admin */
        .admin-gate {
          background: #fff;
          border: 1px solid var(--line);
          border-radius: 3px;
          padding: 28px 24px;
          text-align: center;
          max-width: 340px;
          margin: 20px auto;
        }
        .admin-gate svg { color: var(--ink-soft); margin-bottom: 10px; }
        .admin-gate h3 { font-family: 'Oswald', sans-serif; font-size: 16px; margin: 0 0 6px; color: var(--ink); }
        .admin-gate p { font-size: 13px; color: var(--muted); margin: 0 0 16px; line-height: 1.4; }
        .admin-gate form { display: flex; gap: 8px; }
        .admin-gate input {
          flex: 1;
          border: 1px solid var(--line);
          border-radius: 3px;
          padding: 9px 10px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 13px;
          background: var(--paper);
          text-align: center;
          letter-spacing: 0.08em;
        }
        .admin-gate button {
          background: var(--ink);
          color: var(--paper);
          border: none;
          border-radius: 3px;
          padding: 0 16px;
          cursor: pointer;
          font-family: 'Oswald', sans-serif;
          font-size: 12px;
          text-transform: uppercase;
        }
        .admin-gate-error { color: var(--stamp-orange); font-size: 11.5px; margin-top: 8px; font-family: 'JetBrains Mono', monospace; }
        .admin-gate-hint { font-size: 10.5px; color: var(--muted); margin-top: 12px; font-family: 'JetBrains Mono', monospace; }

        .admin-row {
          display: flex;
          align-items: center;
          gap: 12px;
          background: #fff;
          border: 1px solid var(--line);
          border-radius: 3px;
          padding: 12px 14px;
          margin-bottom: 10px;
          flex-wrap: wrap;
        }
        .admin-row-overdue { border-left: 3px solid var(--esc-color); }
        .admin-toolbar { display: flex; justify-content: flex-end; margin-bottom: 12px; }
        .export-btn {
          display: flex;
          align-items: center;
          gap: 6px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 11.5px;
          background: var(--ink);
          color: var(--paper);
          border: none;
          border-radius: 3px;
          padding: 7px 12px;
          cursor: pointer;
        }
        .export-btn:hover { opacity: 0.9; }
        .admin-row-main { flex: 1; min-width: 160px; }
        .admin-row-title { font-family: 'Oswald', sans-serif; font-size: 14.5px; color: var(--ink); }
        .admin-row-meta { font-family: 'JetBrains Mono', monospace; font-size: 10.5px; color: var(--muted); margin-top: 3px; }
        .admin-select {
          font-family: 'JetBrains Mono', monospace;
          font-size: 11.5px;
          border: 1px solid var(--line);
          border-radius: 3px;
          padding: 6px 8px;
          background: var(--paper);
          color: var(--ink-soft);
        }
        .admin-upvotes { display: flex; align-items: center; gap: 4px; font-family: 'JetBrains Mono', monospace; font-size: 12px; color: var(--muted); }
        .empty-state { text-align: center; color: var(--muted); font-size: 13px; padding: 30px 0; font-style: italic; }

        /* ledger / analytics */
        .ledger-summary { display: flex; gap: 12px; margin-bottom: 18px; flex-wrap: wrap; }
        .ledger-stat {
          flex: 1;
          min-width: 100px;
          background: var(--ink);
          color: var(--paper);
          border-radius: 3px;
          padding: 14px 12px;
          text-align: center;
        }
        .ledger-stat-warn { background: var(--stamp-orange); }
        .ledger-stat-num { display: block; font-family: 'Oswald', sans-serif; font-size: 26px; font-weight: 600; }
        .ledger-stat-label { display: block; font-family: 'JetBrains Mono', monospace; font-size: 10.5px; opacity: 0.7; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.04em; }
        .ledger-card {
          background: #fff;
          border: 1px solid var(--line);
          border-radius: 3px;
          padding: 16px 18px;
          margin-bottom: 14px;
        }
        .ledger-card-title { font-family: 'Oswald', sans-serif; font-size: 13px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--ink-soft); margin: 0 0 12px; }
        .bar-row { display: flex; align-items: center; gap: 10px; margin-bottom: 9px; }
        .bar-row:last-child { margin-bottom: 0; }
        .bar-label { font-size: 12.5px; color: var(--ink-soft); width: 130px; flex-shrink: 0; }
        .bar-track { flex: 1; background: var(--paper-dark); border-radius: 3px; height: 9px; overflow: hidden; }
        .bar-fill { height: 100%; background: var(--stamp-orange); border-radius: 3px; }
        .bar-count { font-family: 'JetBrains Mono', monospace; font-size: 11.5px; color: var(--muted); width: 22px; text-align: right; flex-shrink: 0; }
        .top-row { display: flex; align-items: center; gap: 10px; padding: 7px 0; border-top: 1px dashed var(--line); }
        .top-row:first-child { border-top: none; }
        .top-rank { font-family: 'Oswald', sans-serif; font-weight: 600; color: var(--stamp-orange); width: 16px; }
        .top-title { flex: 1; font-size: 13px; color: var(--ink); }
        .top-votes { display: flex; align-items: center; gap: 4px; font-family: 'JetBrains Mono', monospace; font-size: 11.5px; color: var(--muted); }

        .trend-row { display: flex; align-items: flex-end; gap: 4px; height: 100px; }
        .trend-col { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; height: 100%; min-width: 0; }
        .trend-count { font-family: 'JetBrains Mono', monospace; font-size: 9px; color: var(--muted); margin-bottom: 2px; }
        .trend-bar { width: 100%; max-width: 14px; background: var(--stamp-orange); border-radius: 2px 2px 0 0; }
        .trend-label { font-family: 'JetBrains Mono', monospace; font-size: 8px; color: var(--muted); margin-top: 5px; writing-mode: vertical-rl; transform: rotate(180deg); height: 26px; }

        /* lightbox */
        .lightbox {
          position: fixed;
          inset: 0;
          background: rgba(31,42,68,0.88);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 24px;
        }
        .lightbox img { max-width: 100%; max-height: 78vh; border-radius: 3px; display: block; }
        .lightbox-caption { color: var(--paper); font-family: 'JetBrains Mono', monospace; font-size: 12px; margin-top: 12px; text-align: center; }
        .lightbox-close {
          position: absolute;
          top: 18px;
          right: 18px;
          background: var(--paper);
          border: none;
          border-radius: 50%;
          width: 34px;
          height: 34px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }
        .lightbox-inner { display: flex; flex-direction: column; align-items: center; max-width: 640px; }

        /* toast */
        .toast {
          position: fixed;
          bottom: 20px;
          left: 50%;
          transform: translateX(-50%);
          background: var(--ink);
          color: var(--paper);
          padding: 10px 18px;
          border-radius: 4px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 12.5px;
          box-shadow: 0 4px 14px rgba(0,0,0,0.25);
          z-index: 1100;
          border-left: 4px solid var(--stamp-green);
        }
        .toast.toast-error { border-left-color: var(--stamp-orange); }

        @media (max-width: 520px) {
          .bar-label { width: 90px; font-size: 11.5px; }
        }
      `}</style>

      <div className="header">
        <div className="header-top">
          <div>
            <div className="header-title">
              <ShieldCheck size={20} />
              Civic Ticket
            </div>
            <div className="header-sub">PUBLIC WORKS &amp; COMPLAINT REGISTRY — WARD 14</div>
          </div>
        </div>
        <div className="header-stats">
          <span className="stat">OPEN: {counts.open}</span>
          <span className="stat">IN PROGRESS: {counts.progress}</span>
          <span className="stat">RESOLVED: {counts.resolved}</span>
        </div>
      </div>

      <div className="tabs">
        <button className={`tab-btn ${tab === "submit" ? "active" : ""}`} onClick={() => setTab("submit")}>
          <Plus size={14} /> Submit Report
        </button>
        <button className={`tab-btn ${tab === "board" ? "active" : ""}`} onClick={() => setTab("board")}>
          <ClipboardList size={14} /> Public Board
        </button>
        <button className={`tab-btn ${tab === "analytics" ? "active" : ""}`} onClick={() => setTab("analytics")}>
          <BarChart3 size={14} /> Analytics
        </button>
        <button className={`tab-btn ${tab === "admin" ? "active" : ""}`} onClick={() => setTab("admin")}>
          <ShieldCheck size={14} /> Admin
        </button>
      </div>

      <div className="content">
        {hasRemoteUpdate && (
          <button type="button" className="sync-banner" onClick={applyRemoteUpdate}>
            <RefreshCw size={13} /> New activity on the board — tap to refresh
          </button>
        )}
        {loading ? (
          <div className="loading-state">
            <Loader2 size={16} className="spin" /> Loading the registry…
          </div>
        ) : (
          <>
            {tab === "submit" && (
              <>
                {submitted && (
                  <div className="success-banner">
                    <span>Filed as {submitted} — you can track it on the Public Board.</span>
                    <button onClick={() => setSubmitted(null)}>
                      <X size={14} />
                    </button>
                  </div>
                )}
                <form className="form-card" onSubmit={handleSubmit}>
                  <div className="field">
                    <label>Issue title</label>
                    <input
                      value={form.title}
                      onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                      placeholder="e.g. Broken storm drain cover"
                      required
                    />
                  </div>
                  <div className="field">
                    <label>Category</label>
                    <select
                      value={form.category}
                      onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="field">
                    <label>Description</label>
                    <textarea
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                      placeholder="Describe what's wrong, when you noticed it, and anything else useful."
                      required
                    />
                  </div>
                  <div className="field">
                    <label>Photo (optional)</label>
                    {form.photo ? (
                      <div className="photo-preview">
                        <img src={form.photo} alt="Attached preview" />
                        <button
                          type="button"
                          className="photo-remove"
                          onClick={() => setForm((f) => ({ ...f, photo: null }))}
                        >
                          <X size={13} /> Remove
                        </button>
                      </div>
                    ) : (
                      <label className="photo-upload">
                        <Camera size={16} />
                        <span>Take or choose a photo</span>
                        <input type="file" accept="image/*" capture="environment" onChange={handlePhotoChange} />
                      </label>
                    )}
                    {photoError && <p className="photo-error">{photoError}</p>}
                  </div>
                  <div className="field">
                    <label>Location {pin ? `(marked)` : "(click map to mark)"}</label>
                    <TownMap complaints={complaints} pickable pendingPin={pin} onPick={(p) => { setPin(p); setDismissedDup(false); }} />
                  </div>

                  {nearbyDuplicate && !dismissedDup && (
                    <div className="dup-note">
                      <AlertTriangle size={18} />
                      <div>
                        <p className="dup-note-title">There's already a nearby open report</p>
                        <p className="dup-note-text">
                          "{nearbyDuplicate.title}" ({nearbyDuplicate.id}) looks like the same issue,
                          in the same category, close to your pin. Upvoting it gets the same attention
                          without splitting the record.
                        </p>
                        <div className="dup-note-actions">
                          <button type="button" className="dup-btn dup-btn-primary" onClick={handleUpvoteDuplicate}>
                            Upvote it instead
                          </button>
                          <button type="button" className="dup-btn dup-btn-secondary" onClick={() => setDismissedDup(true)}>
                            File a new report anyway
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  <button
                    className="submit-btn"
                    type="submit"
                    disabled={!form.title.trim() || !form.description.trim() || !pin}
                  >
                    <Send size={14} /> File complaint
                  </button>
                </form>
              </>
            )}

            {tab === "board" && (
              <>
                <div className="filters">
                  <div className="search-box">
                    <Search size={14} />
                    <input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Search reports..."
                    />
                  </div>
                  <select value={filterCat} onChange={(e) => setFilterCat(e.target.value)}>
                    <option value="all">All categories</option>
                    {CATEGORIES.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                  <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                    <option value="all">All statuses</option>
                    <option value="open">Open</option>
                    <option value="progress">In progress</option>
                    <option value="resolved">Resolved</option>
                  </select>
                  <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
                    <option value="recent">Most recent</option>
                    <option value="top">Most upvoted</option>
                    <option value="oldest">Longest waiting</option>
                  </select>
                </div>
                <div className="filters">
                  <label className="mine-toggle">
                    <input type="checkbox" checked={onlyMine} onChange={(e) => setOnlyMine(e.target.checked)} />
                    Only mine
                  </label>
                  <div className="view-toggle">
                    <button className={boardView === "list" ? "active" : ""} onClick={() => setBoardView("list")}>
                      <ClipboardList size={13} /> List
                    </button>
                    <button className={boardView === "map" ? "active" : ""} onClick={() => setBoardView("map")}>
                      <MapIcon size={13} /> Map
                    </button>
                  </div>
                </div>

                {boardView === "map" && (
                  <>
                    <TownMap complaints={filtered} pickable={false} />
                    <div className="map-legend">
                      <span>
                        <span className="legend-dot" style={{ background: STATUS.open.color }} />
                        Open
                      </span>
                      <span>
                        <span className="legend-dot" style={{ background: STATUS.progress.color }} />
                        In progress
                      </span>
                      <span>
                        <span className="legend-dot" style={{ background: STATUS.resolved.color }} />
                        Resolved
                      </span>
                    </div>
                  </>
                )}

                {filtered.length === 0 && (
                  <p className="empty-state">
                    {onlyMine ? "You haven't filed anything that matches these filters." : "No complaints match these filters."}
                  </p>
                )}
                {filtered.map((c) => (
                  <TicketStub
                    key={c.id}
                    complaint={c}
                    mine={myReportIds.includes(c.id)}
                    onUpvote={handleUpvote}
                    onComment={handleComment}
                    onOpenPhoto={(url, title) => setLightbox({ url, title })}
                    onRate={handleRate}
                  />
                ))}
              </>
            )}

            {tab === "analytics" && <Ledger complaints={complaints} />}

            {tab === "admin" && (
              <>
                {!adminUnlocked ? (
                  <div className="admin-gate">
                    <Lock size={26} />
                    <h3>Ward staff only</h3>
                    <p>Enter the staff passcode to update complaint status.</p>
                    <form onSubmit={handlePasscodeSubmit}>
                      <input
                        value={passcodeInput}
                        onChange={(e) => setPasscodeInput(e.target.value)}
                        placeholder="PASSCODE"
                        autoCapitalize="characters"
                      />
                      <button type="submit">Unlock</button>
                    </form>
                    {passcodeError && <p className="admin-gate-error">{passcodeError}</p>}
                    <p className="admin-gate-hint">Demo passcode: WARD14</p>
                  </div>
                ) : (
                  <>
                    <div className="admin-toolbar">
                      <select className="admin-select" value={adminSort} onChange={(e) => setAdminSort(e.target.value)}>
                        <option value="priority">Sort: Priority queue</option>
                        <option value="oldest">Sort: Oldest first</option>
                      </select>
                      <button type="button" className="export-btn" onClick={handleExportCSV}>
                        <Download size={13} /> Export CSV
                      </button>
                    </div>
                    {complaints.length === 0 && <p className="empty-state">No complaints filed yet.</p>}
                    {[...complaints]
                      .sort((a, b) =>
                        adminSort === "priority"
                          ? priorityScore(b) - priorityScore(a)
                          : (a.ts || 0) - (b.ts || 0)
                      )
                      .map((c) => {
                        const escalation = getEscalation(c.ts, c.status, c.category);
                        return (
                          <div
                            className={`admin-row ${escalation ? "admin-row-overdue" : ""}`}
                            key={c.id}
                            style={escalation ? { "--esc-color": escalation.color } : undefined}
                          >
                            <div className="admin-row-main">
                              <div className="admin-row-title">{c.title}</div>
                              <div className="admin-row-meta">
                                {c.id} · {CATEGORIES.find((x) => x.id === c.category)?.label} ·{" "}
                                {c.ts ? timeAgo(c.ts) : c.createdAt}
                              </div>
                              {escalation && (
                                <div className="escalation-badge" style={{ "--esc-color": escalation.color, marginTop: 6, marginBottom: 6 }}>
                                  <Flag size={12} />
                                  {escalation.label}
                                </div>
                              )}
                              <div className="admin-row-controls">
                                <select
                                  className="admin-select"
                                  value={c.assignedTo || ""}
                                  onChange={(e) => handleAssign(c.id, e.target.value)}
                                >
                                  <option value="">Unassigned</option>
                                  {OFFICERS.map((o) => (
                                    <option key={o} value={o}>
                                      {o}
                                    </option>
                                  ))}
                                </select>
                                {c.status === "resolved" && c.photo && !c.resolvedPhoto && (
                                  <label className="proof-upload">
                                    <Camera size={12} />
                                    Add proof photo
                                    <input
                                      type="file"
                                      accept="image/*"
                                      onChange={(e) => {
                                        const file = e.target.files && e.target.files[0];
                                        if (!file) return;
                                        const reader = new FileReader();
                                        reader.onload = () => handleAddProof(c.id, reader.result);
                                        reader.readAsDataURL(file);
                                      }}
                                    />
                                  </label>
                                )}
                              </div>
                            </div>
                            <div className="admin-upvotes">
                              <ThumbsUp size={12} />
                              {c.upvotes}
                            </div>
                            <select
                              className="admin-select"
                              value={c.status}
                              onChange={(e) => handleStatusChange(c.id, e.target.value)}
                            >
                              <option value="open">Open</option>
                              <option value="progress">In progress</option>
                              <option value="resolved">Resolved</option>
                            </select>
                          </div>
                        );
                      })}
                  </>
                )}
              </>
            )}
          </>
        )}
      </div>

      {lightbox && (
        <div className="lightbox" onClick={() => setLightbox(null)}>
          <button className="lightbox-close" onClick={() => setLightbox(null)} aria-label="Close photo">
            <X size={18} />
          </button>
          <div className="lightbox-inner" onClick={(e) => e.stopPropagation()}>
            <img src={lightbox.url} alt={lightbox.title} />
            <p className="lightbox-caption">{lightbox.title}</p>
          </div>
        </div>
      )}

      {toast && <div className={`toast ${toast.kind === "error" ? "toast-error" : ""}`}>{toast.text}</div>}
    </div>
  );
}
