import "./storage.js"; // must load first: defines window.storage
import React from "react";
import { createRoot } from "react-dom/client";
import CivicComplaintPortal from "./CivicComplaintPortal.jsx";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <CivicComplaintPortal />
  </React.StrictMode>
);
